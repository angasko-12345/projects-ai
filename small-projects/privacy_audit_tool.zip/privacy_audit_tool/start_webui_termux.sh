#!/data/data/com.termux/files/usr/bin/bash
# One-tap launcher for Termux on Android.
#
# First-time setup (once):
#   pkg install python -y
#   termux-setup-storage      # lets Python read files in Downloads etc.
#
# Then run this script any time with:
#   bash start_webui_termux.sh
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 not found. Run: pkg install python -y"
  exit 1
fi

echo "Note: browser-history scanning cannot work on Android (browsers sandbox their"
echo "history data; nothing outside the browser itself can read it without root)."
echo "The mail-file scan and the optional online username check both work here."
echo
echo "Starting Privacy Audit UI..."
echo "Open this in Chrome/Firefox on this phone: http://127.0.0.1:8765/"

python3 -m privacy_audit.webui --no-browser "$@"
