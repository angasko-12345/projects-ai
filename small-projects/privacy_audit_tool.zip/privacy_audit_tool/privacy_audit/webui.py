"""Local web UI for the privacy audit tool.

Runs an HTTP server on 127.0.0.1 (loopback only, by design — see main()) and
serves a single mobile-friendly form: pick a mail file, tick some boxes, click
Scan. It calls privacy_audit.main.run_scan() directly, in-process — no
subprocess, so behaviour is identical to the CLI.

Deliberately dependency-free (stdlib only), so it runs unmodified in Termux
after `pkg install python`, with no extra pip installs beyond the optional
`maigret` package for the online-username feature.
"""
from __future__ import annotations

import argparse
import html
import io
import shutil
import socket
import sys
import tempfile
import threading
import time
import traceback
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import main as core

MAX_UPLOAD_BYTES = 200 * 1024 * 1024  # 200 MB; a Takeout mail export can be large.
MAX_HEADER_BYTES = 64 * 1024


class FormPart:
    __slots__ = ('name', 'filename', 'data')

    def __init__(self, name, filename, data):
        self.name = name
        self.filename = filename
        self.data = data


def parse_multipart(body: bytes, boundary: bytes) -> dict[str, list[FormPart]]:
    """Minimal multipart/form-data parser (stdlib has none since `cgi` was removed
    in 3.13). Handles the single-file, few-field form this UI sends; not a general
    MIME parser."""
    delim = b'--' + boundary
    fields: dict[str, list[FormPart]] = {}
    # Split on the delimiter; the first and last chunks are preamble/epilogue.
    for chunk in body.split(delim)[1:-1]:
        chunk = chunk.strip(b'\r\n')
        if not chunk or chunk == b'--':
            continue
        header_blob, _, data = chunk.partition(b'\r\n\r\n')
        if not _:
            continue
        headers = {}
        for line in header_blob.split(b'\r\n'):
            if b':' in line:
                k, _, v = line.partition(b':')
                headers[k.strip().lower().decode('ascii', 'replace')] = v.strip().decode('utf-8', 'replace')
        disp = headers.get('content-disposition', '')
        name = None
        filename = None
        for part in disp.split(';'):
            part = part.strip()
            if part.startswith('name='):
                name = part[5:].strip('"')
            elif part.startswith('filename='):
                filename = part[9:].strip('"')
        if name is None:
            continue
        # data may have a trailing \r\n before the next boundary; strip exactly one.
        if data.endswith(b'\r\n'):
            data = data[:-2]
        fields.setdefault(name, []).append(FormPart(name, filename, data))
    return fields


def field_str(fields: dict, name: str, default: str = '') -> str:
    parts = fields.get(name)
    if not parts:
        return default
    return parts[0].data.decode('utf-8', 'replace').strip()


def field_flag(fields: dict, name: str) -> bool:
    # Checkboxes only appear in the POST body when checked.
    return name in fields


PAGE_CSS = '''
:root{color-scheme:light dark}
*{box-sizing:border-box}
body{font-family:system-ui,Segoe UI,Arial;margin:0;padding:18px;line-height:1.5;font-size:16px;max-width:620px;margin-inline:auto}
h1{font-size:1.3rem;margin-bottom:.2em}
fieldset{border:1px solid #999;border-radius:8px;margin:14px 0;padding:14px}
legend{padding:0 6px;font-weight:600}
label{display:block;margin:10px 0 4px;font-weight:500}
.row{display:flex;align-items:center;gap:8px;margin:10px 0}
.row label{margin:0;font-weight:normal}
input[type=file],input[type=text]{width:100%;padding:10px;font-size:1rem;border:1px solid #aaa;border-radius:6px;background:transparent;color:inherit}
input[type=checkbox]{width:20px;height:20px}
button{width:100%;padding:14px;font-size:1.05rem;font-weight:600;border:none;border-radius:8px;background:#2563eb;color:#fff;margin-top:16px}
button:active{background:#1d4ed8}
.note{padding:12px 14px;border-left:4px solid #555;background:rgba(127,127,127,0.08);border-radius:0 6px 6px 0;margin:14px 0;font-size:0.92rem}
.err{border-left-color:#c0392b;background:rgba(192,57,43,0.1)}
small{color:#777}
.spinner{display:none}
'''

FORM_JS = '''
document.addEventListener('submit', function(e){
  var btn = document.getElementById('go');
  btn.disabled = true;
  btn.textContent = 'Scanning... this can take a while for large mail exports';
});
'''


def render_form(error: str = '', browser_note: str = '') -> str:
    esc = html.escape
    err_html = f'<div class="note err">{esc(error)}</div>' if error else ''
    browser_html = f'<p><small>{esc(browser_note)}</small></p>' if browser_note else ''
    return f'''<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Privacy Audit</title><style>{PAGE_CSS}</style></head><body>
<h1>Local Privacy Audit</h1>
<p><small>Runs entirely on this device. Nothing here leaves the machine unless you tick "online username check" below.</small></p>
{err_html}
<form method="post" action="/scan" enctype="multipart/form-data">
  <fieldset>
    <legend>Mail export (optional)</legend>
    <label for="mailfile">.mbox, .eml, or a Google Takeout .zip</label>
    <input type="file" id="mailfile" name="mailfile" accept=".mbox,.eml,.zip">
  </fieldset>
  <fieldset>
    <legend>Known usernames (optional)</legend>
    <label for="usernamesfile">Text file, one username per line</label>
    <input type="file" id="usernamesfile" name="usernamesfile" accept=".txt">
  </fieldset>
  <fieldset>
    <legend>Options</legend>
    <div class="row"><input type="checkbox" id="browsers" name="browsers" value="1"><label for="browsers">Scan this device's browser history</label></div>
    {browser_html}
    <div class="row"><input type="checkbox" id="online" name="online" value="1"><label for="online">Check usernames against other sites online (contacts external websites)</label></div>
  </fieldset>
  <button type="submit" id="go">Run scan</button>
</form>
<script>{FORM_JS}</script>
</body></html>'''


def render_running_redirect(run_id: str) -> str:
    return f'''<!doctype html><html><head><meta charset="utf-8">
<meta http-equiv="refresh" content="1;url=/report/{html.escape(run_id)}/report.html">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>{PAGE_CSS}</style></head><body><h1>Scan complete</h1>
<p><a href="/report/{html.escape(run_id)}/report.html">View report</a> (redirecting…)</p></body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = 'PrivacyAuditUI/1.1'
    runs_dir: Path = None  # set by make_server

    def log_message(self, fmt, *args):
        pass  # keep terminal output to the scan's own log lines

    def _send_html(self, body: str, status=HTTPStatus.OK):
        data = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path: Path, content_type: str):
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/':
            supported, note = core.browser_scan_supported()
            self._send_html(render_form(browser_note='' if supported else note))
            return
        if parsed.path.startswith('/report/'):
            self._serve_report_file(parsed.path[len('/report/'):])
            return
        self._send_html('<h1>Not found</h1>', HTTPStatus.NOT_FOUND)

    def _serve_report_file(self, rel: str):
        # Guard against path traversal: resolve and require the result stay inside runs_dir.
        try:
            target = (self.runs_dir / rel).resolve()
            target.relative_to(self.runs_dir.resolve())
        except (ValueError, RuntimeError):
            self._send_html('<h1>Not found</h1>', HTTPStatus.NOT_FOUND)
            return
        if not target.is_file():
            self._send_html('<h1>Not found</h1>', HTTPStatus.NOT_FOUND)
            return
        ext = target.suffix.lower()
        content_type = {'.html': 'text/html; charset=utf-8', '.csv': 'text/csv; charset=utf-8',
                         '.json': 'application/json', '.txt': 'text/plain; charset=utf-8'}.get(ext, 'application/octet-stream')
        self._send_file(target, content_type)

    def do_POST(self):
        if urlparse(self.path).path != '/scan':
            self._send_html('<h1>Not found</h1>', HTTPStatus.NOT_FOUND)
            return
        length_hdr = self.headers.get('Content-Length')
        if not length_hdr or not length_hdr.isdigit():
            self._send_html(render_form('Missing Content-Length.'), HTTPStatus.BAD_REQUEST)
            return
        length = int(length_hdr)
        if length > MAX_UPLOAD_BYTES:
            self._send_html(render_form(f'Upload too large (limit {MAX_UPLOAD_BYTES // (1024 * 1024)} MB).'),
                             HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            return
        content_type = self.headers.get('Content-Type', '')
        if 'multipart/form-data' not in content_type or 'boundary=' not in content_type:
            self._send_html(render_form('Malformed form submission.'), HTTPStatus.BAD_REQUEST)
            return
        boundary = content_type.split('boundary=', 1)[1].strip().strip('"').encode('utf-8')
        body = self.rfile.read(length)
        try:
            fields = parse_multipart(body, boundary)
        except Exception:
            self._send_html(render_form('Could not parse the submitted form.'), HTTPStatus.BAD_REQUEST)
            return

        run_id = time.strftime('%Y%m%d-%H%M%S') + f'-{threading.get_ident() % 10000}'
        run_dir = self.runs_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix='privacy_audit_ui_'))
        try:
            mail_path = None
            mail_parts = fields.get('mailfile')
            if mail_parts and mail_parts[0].filename:
                mp = mail_parts[0]
                mail_path = work / ('upload_' + Path(mp.filename).name)
                mail_path.write_bytes(mp.data)

            usernames_path = None
            user_parts = fields.get('usernamesfile')
            if user_parts and user_parts[0].filename:
                up = user_parts[0]
                usernames_path = work / ('usernames_' + Path(up.filename).name)
                usernames_path.write_bytes(up.data)

            log_lines = []
            core.run_scan(
                mail=mail_path,
                usernames_path=usernames_path,
                browsers=field_flag(fields, 'browsers'),
                online_usernames=field_flag(fields, 'online'),
                out=run_dir,
                log=log_lines.append,
            )
            print('\n'.join(log_lines))
            self._send_html(render_running_redirect(run_id))
        except Exception as e:
            traceback.print_exc()
            self._send_html(render_form(f'Scan failed: {e}'), HTTPStatus.INTERNAL_SERVER_ERROR)
        finally:
            shutil.rmtree(work, ignore_errors=True)


def make_server(host: str, port: int, runs_dir: Path) -> ThreadingHTTPServer:
    runs_dir.mkdir(parents=True, exist_ok=True)
    handler = type('BoundHandler', (Handler,), {'runs_dir': runs_dir})
    return ThreadingHTTPServer((host, port), handler)


def local_ips() -> list[str]:
    ips = set()
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ':' not in ip:  # skip IPv6 for a shorter, friendlier list
                ips.add(ip)
    except Exception:
        pass
    return sorted(ips)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Local web UI for the privacy audit tool.')
    parser.add_argument('--host', default='127.0.0.1',
                         help='Bind address. Default 127.0.0.1 (this device only). '
                              'Use 0.0.0.0 only if you understand that anyone on your '
                              'network could then reach this page and read your report output.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--out', type=Path, default=Path('output'), help='Base directory for scan output.')
    parser.add_argument('--no-browser', action='store_true', help="Don't auto-open a browser tab.")
    args = parser.parse_args(argv)

    if args.host not in ('127.0.0.1', 'localhost', '::1'):
        print('WARNING: binding to a non-loopback address. This report contains emails, '
              'usernames and browsing history. Anyone who can reach this address on your '
              'network will be able to view and trigger scans.', file=sys.stderr)

    server = make_server(args.host, args.port, args.out)
    url = f'http://{"127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host}:{args.port}/'
    print(f'Privacy Audit UI running at {url}')
    if args.host == '0.0.0.0':
        for ip in local_ips():
            print(f'  also reachable at http://{ip}:{args.port}/  (see warning above)')
    print('Press Ctrl+C to stop.')
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
