import http.client
import json
import re
import shutil
import tempfile
import threading
import unittest
from pathlib import Path

from privacy_audit import webui


class WebUITests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix='privacy_audit_ui_test_'))
        self.server = webui.make_server('127.0.0.1', 0, self.tmp)  # port 0 = OS picks a free port
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def req(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        try:
            conn.request(method, path, body=body, headers=headers or {})
            r = conn.getresponse()
            return r.status, r.read()
        finally:
            conn.close()

    def test_form_serves(self):
        status, data = self.req('GET', '/')
        self.assertEqual(status, 200)
        self.assertIn(b'Local Privacy Audit', data)
        self.assertIn(b'viewport', data)  # responsive meta tag present

    def test_unknown_path_404(self):
        status, _ = self.req('GET', '/nope')
        self.assertEqual(status, 404)

    def _upload_mail(self, mail_bytes: bytes, filename='test.eml'):
        boundary = 'BOUNDARYX'
        body = (
            f'--{boundary}\r\nContent-Disposition: form-data; name="mailfile"; filename="{filename}"\r\n'
            'Content-Type: message/rfc822\r\n\r\n'
        ).encode() + mail_bytes + f'\r\n--{boundary}--\r\n'.encode()
        return self.req('POST', '/scan', body=body, headers={
            'Content-Type': f'multipart/form-data; boundary={boundary}',
            'Content-Length': str(len(body)),
        })

    def test_scan_via_upload_and_report_fetch(self):
        mail = (b'Subject: Welcome - verify your email\r\nFrom: site@testshop.com\r\n'
                b'To: user@gmail.com\r\n\r\nVerify your email at https://testshop.com/verify')
        status, data = self._upload_mail(mail)
        self.assertEqual(status, 200)
        m = re.search(r'/report/([^/"]+)/report\.html', data.decode())
        self.assertIsNotNone(m)
        run_id = m.group(1)

        status, rep = self.req('GET', f'/report/{run_id}/report.html')
        self.assertEqual(status, 200)
        self.assertIn(b'testshop.com', rep)
        self.assertIn(b'viewport', rep)

        status, sj = self.req('GET', f'/report/{run_id}/summary.json')
        self.assertEqual(status, 200)
        summary = json.loads(sj)
        self.assertEqual(summary['unique_domains'], 1)

        # Every declared output file should actually exist on disk for this run.
        for name in ('accounts.csv', 'domains.csv', 'browser.csv', 'usernames.txt', 'summary.json', 'report.html'):
            self.assertTrue((self.tmp / run_id / name).exists(), name)

    def test_path_traversal_blocked(self):
        status, _ = self.req('GET', '/report/../../../../etc/passwd')
        self.assertEqual(status, 404)
        # Even with a valid-looking run_id prefix.
        status, _ = self.req('GET', '/report/somerun/../../../etc/passwd')
        self.assertEqual(status, 404)

    def test_oversized_content_length_rejected_without_hang(self):
        status, _ = self.req('POST', '/scan', body=b'', headers={
            'Content-Type': 'multipart/form-data; boundary=x',
            'Content-Length': str(webui.MAX_UPLOAD_BYTES + 1),
        })
        self.assertEqual(status, 413)

    def test_missing_content_length_rejected(self):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        conn.putrequest('POST', '/scan', skip_host=True, skip_accept_encoding=True)
        conn.putheader('Content-Type', 'multipart/form-data; boundary=x')
        conn.endheaders()
        r = conn.getresponse()
        self.assertEqual(r.status, 400)
        r.read()
        conn.close()

    def test_malformed_content_type_rejected(self):
        status, _ = self.req('POST', '/scan', body=b'x', headers={
            'Content-Type': 'text/plain',
            'Content-Length': '1',
        })
        self.assertEqual(status, 400)

    def test_multipart_parser_roundtrip(self):
        boundary = b'ZZZ'
        body = (b'--ZZZ\r\nContent-Disposition: form-data; name="browsers"\r\n\r\n1\r\n'
                b'--ZZZ\r\nContent-Disposition: form-data; name="mailfile"; filename="a.eml"\r\n'
                b'Content-Type: message/rfc822\r\n\r\nHELLO\r\n--ZZZ--\r\n')
        fields = webui.parse_multipart(body, boundary)
        self.assertEqual(webui.field_str(fields, 'browsers'), '1')
        self.assertTrue(webui.field_flag(fields, 'browsers'))
        self.assertFalse(webui.field_flag(fields, 'online'))
        self.assertEqual(fields['mailfile'][0].filename, 'a.eml')
        self.assertEqual(fields['mailfile'][0].data, b'HELLO')


if __name__ == '__main__':
    unittest.main()
