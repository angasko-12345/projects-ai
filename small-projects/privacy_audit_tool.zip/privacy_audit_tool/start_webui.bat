@echo off
setlocal
cd /d "%~dp0"
echo Starting Privacy Audit UI...
echo A browser tab should open automatically. If not, go to http://127.0.0.1:8765/
echo Close this window (or press Ctrl+C) to stop the scanner.
py -m privacy_audit.webui %*
endlocal
