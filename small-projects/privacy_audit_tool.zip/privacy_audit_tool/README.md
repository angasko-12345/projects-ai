# Local Privacy Audit Tool

A read-only, local-first footprint discovery tool. It does **not** delete accounts,
change settings, submit removal requests, or collect passwords.

Works on Windows, and on Android via Termux (with the limitation below). A command-line
mode is also available for scripting.

## What it can scan

- Google Takeout Gmail `.zip` archives
- `.mbox` and `.eml` mail files
- Local Chrome, Edge, Brave, and Firefox browsing history/bookmarks — **Windows only, see limitation below**
- A manual list of old usernames
- Optional Maigret username checks, only when explicitly requested

## Platform support and limitations

| Feature | Windows | Android (Termux) |
|---|---|---|
| Mail file / Takeout zip scan | yes | yes |
| Browser history scan | yes | **no — not possible, see below** |
| Online username check (Maigret) | yes, after `pip install maigret` | yes, after `pip install maigret`; slower and less reliable on a phone |
| Web UI (this README's main path) | yes | yes |

**Browser-history scanning cannot work on Android, with or without this tool.** Chrome,
Firefox, and other browsers store history in a database inside that browser's own
private, sandboxed app storage. No other app — including Termux — can read it without
root. This is an OS-level restriction, not a missing feature. On Android the UI still
shows the checkbox but will tell you upfront it can't be used, rather than silently
returning nothing.

Desktop macOS/Linux browser paths are not implemented; the browser scan only recognizes
Windows profile locations.

## Requirements

Python 3.10+. No third-party packages are needed for the core scanner or the web UI —
both use only the standard library, deliberately, so Termux needs nothing beyond
`pkg install python`.

## Quick start — web UI (recommended)

This is one page: pick a mail file, tick a couple of boxes, click Run. It renders fine
on a phone screen and works the same way on Windows and Android.

**Windows:** double-click `start_webui.bat`. It opens `http://127.0.0.1:8765/` in your
browser automatically.

**Android (Termux):**
```sh
pkg install python -y
termux-setup-storage        # once, so Python can read files in Downloads etc.
bash start_webui_termux.sh
```
Then open `http://127.0.0.1:8765/` in Chrome or Firefox **on the same phone**.

The server binds to `127.0.0.1` (this device only) by default — nothing on your network
can reach it. Output for each run is written under `output/<timestamp>/`, and the report
opens automatically when a scan finishes.

To stop the server, close the terminal window or press Ctrl+C.

## Quick start — command line

1. Put old usernames, one per line, in `inputs\usernames.txt`.
2. Obtain a local Google Takeout Gmail export. Keep the archive private.
3. Run:

```powershell
.\run_audit.ps1 -Mail 'C:\Path\Takeout.zip'
```

To also inspect local browser history/bookmarks (Windows only, see limitation above):

```powershell
.\run_audit.ps1 -Mail 'C:\Path\Takeout.zip' -Browsers
```

Output appears in `output\`.

If PowerShell blocks the script (execution policy), use `run_audit.bat` with the same
options (`run_audit.bat --mail C:\Path\Takeout.zip --browsers`) or run
`powershell -ExecutionPolicy Bypass -File .\run_audit.ps1 ...`.

On Termux, the equivalent is `python3 -m privacy_audit.main --mail ~/storage/downloads/Takeout.zip`.

## Outputs

- `report.html` - readable local report, responsive down to phone width
- `accounts.csv` - evidence for possible accounts/services
- `domains.csv` - domains found and how often they appeared
- `browser.csv` - browser history/bookmark discoveries
- `usernames.txt` - deduplicated supplied + conservatively inferred usernames
- `summary.json` - machine-readable summary
- `warnings.txt` - written only if something could not be read (locked browser DB, bad mail file, unsupported platform, etc.)

## Optional online username scan

Install Maigret separately:

```powershell
py -m pip install maigret
```
(Termux: `pip install maigret`.)

Then explicitly opt in, either by ticking the box in the web UI or with the CLI flag.
**Only usernames you supplied are sent** — via the usernames file, or the web form's
usernames upload. Usernames the tool infers from your mail are never sent, and names
that begin with `-` or contain unusual characters are skipped. Usernames go out in
batches of 20.

```powershell
.\run_audit.ps1 -Usernames 'inputs\usernames.txt' -OnlineUsernames
```

The tool creates `ONLINE_SCAN_WARNING.txt` to make the networked nature explicit.

## Suggested workflow

1. Build your username list.
2. Export Gmail data locally.
3. Run the default offline scan.
4. Review `report.html`.
5. Confirm each candidate manually.
6. Secure needed accounts and delete abandoned ones manually.
7. Only then start data-broker removal.

## Important limitations

This is an evidence finder, not a perfect account detector. A domain in your mail/history
may be a newsletter, purchase, login provider, or unrelated link. Always verify
candidates before deleting an account.

Browser scanning (Windows only) is best-effort because browsers can keep database files
locked. Close the relevant browser before scanning. Read failures are reported in the
console, `warnings.txt` and the report; a `Warnings: 0` line means nothing was skipped.
Only the 5000 most recent history rows per profile are read, and the HTML report shows
the first 5000 candidates / 1000 browser rows (CSVs are complete).

Confidence labels are heuristic: they count distinct signup/security phrases in the
message and attribute them to the sender only.

CSV cells that start with `=`, `+`, `-` or `@` are prefixed with an apostrophe so Excel
cannot run them as formulas.

The web UI accepts uploads up to 200 MB and only ever writes inside its own output
folder — it will not read or serve any other file on your device.

Keep the generated reports private: they can contain emails, usernames, URLs, and other
sensitive information.
